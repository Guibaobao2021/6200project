from elasticsearch import Elasticsearch
from flask import Flask, render_template, request

INDEX_NAME = 'americanlife'
app = Flask(__name__)
es = Elasticsearch('http://localhost:9200')


@app.route('/search', methods=['POST'])
def search():
    query = request.form['query']
    body = {"query": {"query_string": {"query": query}}}
    response = es.search(index=INDEX_NAME, body=body)
    results = []
    for hit in response.body['hits']['hits']:
        speakers = ', '.join(hit["_source"]["speakers"].split('\n'))
        results.append({'_id': hit['_id'], 'episode_id': hit['_source']['episode_id'], 'speakers': speakers})
    return render_template('query.html', results=results)


@app.route('/episode/<_id>', methods=['GET'])
def get_episode(_id):
    response = es.get(index=INDEX_NAME, id=_id)
    transcript = response.body['_source']['transcript'].split('\n')
    episode = {'episode_id': response.body['_source']['episode_id'], 'transcript': transcript}
    return render_template('transcript.html', episode=episode)


@app.route('/')
def index():
    return render_template('query.html')


if __name__ == '__main__':
    app.run()
