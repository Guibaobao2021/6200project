import json
from elasticsearch import Elasticsearch

DATA_PATH = 'americanlife/train-transcripts-aligned.json'
INDEX_NAME = 'americanlife'
mapping = {
    "mappings": {
        "properties": {
            "episode_id": {"type": "text"},
            "speakers": {"type": "text"},
            "transcript": {"type": "text"}
        }
    }
}


def create_index(client: Elasticsearch):
    return client.indices.create(index=INDEX_NAME, body=mapping, ignore=400)


def main():
    es = Elasticsearch('http://localhost:9200')
    response = es.ping()
    if not response:
        print("ES not accessible, exit")
        exit(1)
    create_index(client=es)
    with open(DATA_PATH, 'r') as f:
        data = json.loads(f.read())
        for ep, contents in data.items():
            speaker_set = set()
            utterances = []
            for content in contents:
                speaker_set.add(content['speaker'])
                utterances.append(f'{content["speaker"]}: {content["utterance"]}')
            speakers_list = list(speaker_set)
            speakers_list.sort()
            speakers = ',\n'.join(speakers_list)
            transcript = '\n'.join(utterances)
            es.index(index=INDEX_NAME, body={'episode_id': ep, 'speakers': speakers, 'transcript': transcript})
            print(f'finished indexing episode {ep}')
    print("finished indexing all docs")


if __name__ == '__main__':
    main()
